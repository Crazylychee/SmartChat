export default class MessageTypeConstant {
    //全员还是私发
    public static publicState = 'public';
    public static privateState = 'private';
    //普通消息还是文件
    public static messageStyle = 'message';
    public static fileStyle = 'file';
}