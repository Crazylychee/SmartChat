//事件类型名称
export default class EventStant {
    //获取新的成员
    public static NEW_MEMBER: string = 'new_member';
    //获取新的offer
    public static MEW_OFFER: string = 'new_offer';
    //获取新的answer
    public static NEW_ANSWER: string = 'new_answer';
    //异常处理
    public static HANDLE_EXCEPTION: string = 'handle_exception';
}