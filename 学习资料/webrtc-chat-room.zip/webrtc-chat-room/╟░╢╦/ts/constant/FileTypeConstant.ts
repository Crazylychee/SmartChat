//用于判断文件是否可以直接显示
export default class FileTypeConstant {
    public static imgType = 'image';
    public static videoType = 'video';
}