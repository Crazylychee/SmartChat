//请求数据类型
class HeaderInfo{
    //key
    public static KEY = 'Content-Type';
    //json，只需要判断json其他的无需关心
    public static JSON_VALUE = 'application/json';
}

export default HeaderInfo;