//请求类型
enum RequestTypeConstant {
    POST = 'POST'
}
export default RequestTypeConstant;