import MainBiz from "./main/MainBiz.js";

window.onload = () => {
    //开始运行
    MainBiz.run();

    //此处可用作调试
    //...
}