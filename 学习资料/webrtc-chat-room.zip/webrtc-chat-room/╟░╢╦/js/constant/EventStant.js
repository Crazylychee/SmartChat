class EventStant {
}
EventStant.NEW_MEMBER = 'new_member';
EventStant.MEW_OFFER = 'new_offer';
EventStant.NEW_ANSWER = 'new_answer';
EventStant.HANDLE_EXCEPTION = 'handle_exception';
export default EventStant;
