class HeaderInfo {
}
HeaderInfo.KEY = 'Content-Type';
HeaderInfo.JSON_VALUE = 'application/json';
export default HeaderInfo;
