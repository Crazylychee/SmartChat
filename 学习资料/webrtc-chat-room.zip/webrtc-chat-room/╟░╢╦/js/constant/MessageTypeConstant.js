class MessageTypeConstant {
}
MessageTypeConstant.publicState = 'public';
MessageTypeConstant.privateState = 'private';
MessageTypeConstant.messageStyle = 'message';
MessageTypeConstant.fileStyle = 'file';
export default MessageTypeConstant;
