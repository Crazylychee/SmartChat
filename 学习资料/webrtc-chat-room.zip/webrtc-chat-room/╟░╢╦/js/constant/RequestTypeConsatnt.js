var RequestTypeConstant;
(function (RequestTypeConstant) {
    RequestTypeConstant["POST"] = "POST";
})(RequestTypeConstant || (RequestTypeConstant = {}));
export default RequestTypeConstant;
