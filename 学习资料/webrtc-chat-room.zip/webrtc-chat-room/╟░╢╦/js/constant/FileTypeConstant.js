class FileTypeConstant {
}
FileTypeConstant.imgType = 'image';
FileTypeConstant.videoType = 'video';
export default FileTypeConstant;
