import MainBiz from "./main/MainBiz.js";
window.onload = () => {
    MainBiz.run();
};
